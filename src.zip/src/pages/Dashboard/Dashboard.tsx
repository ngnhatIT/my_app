const Dashboard = () => {
  return <div className="text-center">Reset Password Page (To be implemented)</div>;
};
export default Dashboard;